package mituran.gglua.tool;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;

public class EncryptTutorialChapterAdapter extends RecyclerView.Adapter<EncryptTutorialChapterAdapter.ChapterViewHolder> {

    private Context context;
    private List<EncryptTutorialChapter> chapters;
    private OnChapterClickListener listener;

    public interface OnChapterClickListener {
        void onChapterClick(EncryptTutorialChapter chapter, int position);
    }

    public EncryptTutorialChapterAdapter(Context context, List<EncryptTutorialChapter> chapters) {
        this.context = context;
        this.chapters = chapters;
    }

    public void setOnChapterClickListener(OnChapterClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public ChapterViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_encrypt_tutorial_chapter, parent, false);
        return new ChapterViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ChapterViewHolder holder, int position) {
        EncryptTutorialChapter chapter = chapters.get(position);

        holder.tvChapterNumber.setText(String.valueOf(chapter.getChapterNumber()));
        holder.tvChapterName.setText(chapter.getTitle());
        holder.tvChapterDescription.setText(chapter.getDescription());

        // 显示完成状态
        holder.ivCompleted.setVisibility(chapter.isCompleted() ? View.VISIBLE : View.GONE);

        // 设置点击事件
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onChapterClick(chapter, position);
            }
        });
    }

    @Override
    public int getItemCount() {
        return chapters.size();
    }

    static class ChapterViewHolder extends RecyclerView.ViewHolder {
        TextView tvChapterNumber;
        TextView tvChapterName;
        TextView tvChapterDescription;
        ImageView ivCompleted;

        ChapterViewHolder(@NonNull View itemView) {
            super(itemView);
            tvChapterNumber = itemView.findViewById(R.id.tv_chapter_number);
            tvChapterName = itemView.findViewById(R.id.tv_chapter_name);
            tvChapterDescription = itemView.findViewById(R.id.tv_chapter_description);
            ivCompleted = itemView.findViewById(R.id.iv_completed);
        }
    }
}