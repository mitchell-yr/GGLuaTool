package mituran.gglua.tool;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.navigation.NavigationView;
import io.noties.markwon.Markwon;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

public class GGTutorialActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private TextView contentTextView;
    private RecyclerView chapterRecyclerView;
    private GGTutorialChapterAdapter chapterAdapter;
    private Markwon markwon;
    private List<Chapter> chapters;
    private int currentChapterIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gg_tutorial);

        // 初始化Markwon
        markwon = Markwon.create(this);

        // 初始化视图
        initViews();

        // 初始化教程章节
        initChapters();

        // 设置适配器
        setupRecyclerView();

        // 显示第一章
        displayChapter(0);
    }

    private void initViews() {
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeAsUpIndicator(R.drawable.ic_menu);
        getSupportActionBar().setTitle("GG修改器教程");

        drawerLayout = findViewById(R.id.drawer_layout);
        navigationView = findViewById(R.id.nav_view);
        contentTextView = findViewById(R.id.content_text);
        chapterRecyclerView = findViewById(R.id.chapter_recycler);

        // 工具栏点击打开侧边栏
        toolbar.setNavigationOnClickListener(v -> drawerLayout.openDrawer(navigationView));
    }

    private void initChapters() {
        chapters = new ArrayList<>();

        chapters.add(new Chapter(
                "第一章：GameGuardian简介",
                "# GameGuardian简介\n\n" +
                        "## 什么是GameGuardian？\n\n" +
                        "GameGuardian（简称GG）是一款强大的游戏修改工具，可以帮助你修改游戏中的数值。\n\n" +
                        "## 主要功能\n\n" +
                        "- **数值搜索**：搜索并修改游戏内存中的数值\n" +
                        "- **模糊搜索**：在不知道确切数值时进行搜索\n" +
                        "- **脚本支持**：使用Lua脚本自动化修改\n" +
                        "- **游戏加速**：调整游戏运行速度\n\n" +
                        "## 注意事项\n\n" +
                        "> ⚠️ 请仅在单机游戏中使用，不要在联机游戏中作弊\n\n" +
                        "准备好了吗？让我们开始学习吧！"
        ));

        chapters.add(new Chapter(
                "第二章：基础搜索",
                "# 基础搜索教程\n\n" +
                        "## 精确数值搜索\n\n" +
                        "这是最基础的搜索方式，适用于你知道确切数值的情况。\n\n" +
                        "### 操作步骤\n\n" +
                        "1. 打开GG，选择要修改的游戏进程\n" +
                        "2. 记下游戏中的数值（如金币：1000）\n" +
                        "3. 点击搜索图标，输入**1000**\n" +
                        "4. 选择数据类型（通常是**Dword**）\n" +
                        "5. 点击搜索\n\n" +
                        "### 筛选结果\n\n" +
                        "- 改变游戏中的数值\n" +
                        "- 使用**增量搜索**或**精确搜索**缩小范围\n" +
                        "- 重复直到结果少于100个\n\n" +
                        "```lua\n" +
                        "-- 示例脚本\n" +
                        "gg.searchNumber('1000', gg.TYPE_DWORD)\n" +
                        "```"
        ));

        chapters.add(new Chapter(
                "第三章：模糊搜索",
                "# 模糊搜索技巧\n\n" +
                        "## 什么是模糊搜索？\n\n" +
                        "当你不知道确切数值，但知道数值变化趋势时使用。\n\n" +
                        "## 搜索类型\n\n" +
                        "### 1. 增大/减小\n" +
                        "适用于血量、经验值等会变化的数值\n\n" +
                        "### 2. 变化/未变化\n" +
                        "找出发生变化或保持不变的数值\n\n" +
                        "### 3. 增加/减少指定值\n" +
                        "精确知道变化量时使用\n\n" +
                        "## 实战案例\n\n" +
                        "**修改游戏血量**\n\n" +
                        "1. 进行**初始搜索**（选择Dword类型）\n" +
                        "2. 受到伤害后，搜索**减小**\n" +
                        "3. 恢复血量后，搜索**增大**\n" +
                        "4. 重复2-3步直到结果<20\n" +
                        "5. 修改并锁定数值\n\n" +
                        "> 💡 提示：耐心是成功的关键！"
        ));

        chapters.add(new Chapter(
                "第四章：数据类型详解",
                "# 数据类型选择\n\n" +
                        "## 常用数据类型\n\n" +
                        "| 类型 | 说明 | 范围 | 用途 |\n" +
                        "|------|------|------|------|\n" +
                        "| **Dword** | 32位整数 | 0~4,294,967,295 | 金币、等级 |\n" +
                        "| **Float** | 浮点数 | 小数 | 血量、坐标 |\n" +
                        "| **Double** | 双精度浮点 | 大小数 | 精确数值 |\n" +
                        "| **Byte** | 8位整数 | 0~255 | 开关、状态 |\n" +
                        "| **Word** | 16位整数 | 0~65,535 | 较小数值 |\n\n" +
                        "## 如何选择？\n\n" +
                        "### Dword（最常用）\n" +
                        "- 整数类型数值\n" +
                        "- 金币、钻石、经验\n\n" +
                        "### Float\n" +
                        "- 带小数点的数值\n" +
                        "- 血量、攻击力、速度\n\n" +
                        "### Double\n" +
                        "- 需要高精度时\n" +
                        "- 大额数值\n\n" +
                        "### 自动类型\n" +
                        "不确定时可选择**Auto**，但速度较慢"
        ));

        chapters.add(new Chapter(
                "第五章：群组搜索",
                "# 群组搜索高级技巧\n\n" +
                        "## 什么是群组搜索？\n\n" +
                        "同时搜索多个相关联的数值，快速定位目标。\n\n" +
                        "## 语法格式\n\n" +
                        "```\n" +
                        "100;200;300\n" +
                        "```\n" +
                        "- 用**分号**分隔不同数值\n" +
                        "- 支持不同数据类型混合\n\n" +
                        "## 高级技巧\n\n" +
                        "### 使用通配符\n" +
                        "```\n" +
                        "100;?;300\n" +
                        "```\n" +
                        "**?** 代表任意数值\n\n" +
                        "### 指定范围\n" +
                        "```\n" +
                        "100~200;500\n" +
                        "```\n" +
                        "搜索100到200之间的值，后面跟着500\n\n" +
                        "### 指定类型\n" +
                        "```\n" +
                        "100D;50.5F;200W\n" +
                        "```\n" +
                        "- **D**: Dword\n" +
                        "- **F**: Float\n" +
                        "- **W**: Word\n\n" +
                        "## 实战示例\n\n" +
                        "**修改角色属性**\n\n" +
                        "假设HP=500, MP=300, ATK=100\n\n" +
                        "```\n" +
                        "500F;300F;100D\n" +
                        "```\n\n" +
                        "这将大大提高搜索效率！"
        ));

        chapters.add(new Chapter(
                "第六章：内存范围",
                "# 内存范围选择\n\n" +
                        "## 为什么要选择内存范围？\n\n" +
                        "不同的内存区域存储不同类型的数据，选择正确的范围可以：\n" +
                        "- ⚡ 提高搜索速度\n" +
                        "- 🎯 减少无关结果\n" +
                        "- 💾 降低内存占用\n\n" +
                        "## 内存类型\n\n" +
                        "### A Anonymous（匿名）\n" +
                        "- 游戏动态分配的内存\n" +
                        "- **最常用**，推荐首选\n\n" +
                        "### Ca C++ alloc\n" +
                        "- C++分配的内存\n" +
                        "- 某些Unity游戏使用\n\n" +
                        "### Cd C++ .data\n" +
                        "- C++静态数据\n" +
                        "- 不常改变的数值\n\n" +
                        "### J Java Heap\n" +
                        "- Java堆内存\n" +
                        "- Android原生游戏\n\n" +
                        "### S Stack\n" +
                        "- 栈内存\n" +
                        "- 临时变量\n\n" +
                        "## 推荐设置\n\n" +
                        "### 新手推荐\n" +
                        "```\n" +
                        "A + Ca + Cd\n" +
                        "```\n\n" +
                        "### 高级用户\n" +
                        "根据游戏引擎选择：\n" +
                        "- **Unity**: A + Ca\n" +
                        "- **Unreal**: A + Cd\n" +
                        "- **原生Android**: J + A\n\n" +
                        "> 🔍 如果搜索不到，可以勾选全部范围"
        ));

        chapters.add(new Chapter(
                "第七章：数值锁定",
                "# 数值锁定与冻结\n\n" +
                        "## 什么是锁定？\n\n" +
                        "将找到的数值固定，防止游戏改变它。\n\n" +
                        "## 操作方法\n\n" +
                        "### 基础锁定\n" +
                        "1. 搜索并找到目标地址\n" +
                        "2. 点击数值进入编辑\n" +
                        "3. 修改为想要的值\n" +
                        "4. 勾选**冻结**复选框\n\n" +
                        "### 批量锁定\n" +
                        "1. 长按选择多个地址\n" +
                        "2. 点击**编辑**\n" +
                        "3. 输入新数值\n" +
                        "4. 勾选**冻结**\n\n" +
                        "## 冻结模式\n\n" +
                        "### 普通冻结\n" +
                        "```lua\n" +
                        "gg.addListItems({{address = 0x12345678, flags = 4, value = 999, freeze = true}})\n" +
                        "```\n" +
                        "定期写入数值\n\n" +
                        "### 可能/或许\n" +
                        "- **可能**：有时写入\n" +
                        "- **或许**：很少写入\n" +
                        "- 用于防检测\n\n" +
                        "## 注意事项\n\n" +
                        "⚠️ **警告**\n" +
                        "- 不要锁定关键系统数值\n" +
                        "- 某些数值锁定可能导致游戏崩溃\n" +
                        "- 建议先测试再锁定\n\n" +
                        "✅ **建议**\n" +
                        "- 定期保存列表\n" +
                        "- 给地址添加描述\n" +
                        "- 及时清理不需要的冻结"
        ));

        chapters.add(new Chapter(
                "第八章：进阶技巧",
                "# 进阶修改技巧\n\n" +
                        "## 指针搜索\n\n" +
                        "### 什么是指针？\n" +
                        "指针是指向内存地址的地址，用于找到动态变化的数值。\n\n" +
                        "### 使用步骤\n" +
                        "1. 找到目标数值的地址\n" +
                        "2. 搜索该地址（类型选Qword）\n" +
                        "3. 重启游戏，用找到的指针+偏移定位\n\n" +
                        "## 内存编辑\n\n" +
                        "### Goto\n" +
                        "直接跳转到指定地址\n" +
                        "```\n" +
                        "Goto: 0x12345678\n" +
                        "```\n\n" +
                        "### 十六进制编辑\n" +
                        "直接修改内存字节码\n\n" +
                        "## 游戏加速\n\n" +
                        "调整游戏运行速度：\n" +
                        "- 0.1x ~ 100x\n" +
                        "- 用于跳过动画、快速刷怪\n\n" +
                        "## 差异对比\n\n" +
                        "保存游戏状态，对比内存变化：\n" +
                        "1. 保存当前内存\n" +
                        "2. 改变游戏状态\n" +
                        "3. 进行差异搜索\n\n" +
                        "## Lua脚本入门\n\n" +
                        "```lua\n" +
                        "-- 简单的金币修改脚本\n" +
                        "gg.clearResults()\n" +
                        "gg.setRanges(gg.REGION_ANONYMOUS)\n" +
                        "gg.searchNumber('1000', gg.TYPE_DWORD)\n" +
                        "local results = gg.getResults(100)\n" +
                        "for i, v in ipairs(results) do\n" +
                        "    v.value = '999999'\n" +
                        "end\n" +
                        "gg.setValues(results)\n" +
                        "gg.toast('修改成功！')\n" +
                        "```\n\n" +
                        "> 🚀 掌握这些技巧，你已经是GG高手了！"
        ));
    }

    private void setupRecyclerView() {
        chapterRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        chapterAdapter = new GGTutorialChapterAdapter(chapters, position -> {
            displayChapter(position);
            drawerLayout.closeDrawers();
        });
        chapterRecyclerView.setAdapter(chapterAdapter);
    }

    private void displayChapter(int index) {
        if (index >= 0 && index < chapters.size()) {
            currentChapterIndex = index;
            Chapter chapter = chapters.get(index);
            markwon.setMarkdown(contentTextView, chapter.getContent());
            chapterAdapter.setSelectedPosition(index);
            getSupportActionBar().setTitle(chapter.getTitle());
        }
    }

    // 章节数据类
    static class Chapter {
        private String title;
        private String content;

        public Chapter(String title, String content) {
            this.title = title;
            this.content = content;
        }

        public String getTitle() { return title; }
        public String getContent() { return content; }
    }
}