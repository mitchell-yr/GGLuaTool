package mituran.gglua.tool;


import android.graphics.Bitmap;
import android.graphics.pdf.PdfRenderer;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class GGPDFDocumentViewActivity extends AppCompatActivity {

    private ImageView imageView;
    private Button btnPrevious;
    private Button btnNext;

    private PdfRenderer pdfRenderer;
    private PdfRenderer.Page currentPage;
    private ParcelFileDescriptor parcelFileDescriptor;
    private int currentPageIndex = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gg_pdf_document_view);

        imageView = findViewById(R.id.imageView);
        btnPrevious = findViewById(R.id.btnPrevious);
        btnNext = findViewById(R.id.btnNext);

        // 从assets复制PDF到缓存目录
        File file = copyPdfFromAssets();

        if (file != null) {
            try {
                openPdfRenderer(file);
                showPage(0);
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(this, "无法打开PDF文件", Toast.LENGTH_SHORT).show();
            }
        }

        // 上一页按钮
        btnPrevious.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (currentPageIndex > 0) {
                    showPage(--currentPageIndex);
                }
            }
        });

        // 下一页按钮
        btnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (pdfRenderer != null && currentPageIndex < pdfRenderer.getPageCount() - 1) {
                    showPage(++currentPageIndex);
                }
            }
        });
    }

    /**
     * 从assets目录复制PDF文件到缓存目录
     */
    private File copyPdfFromAssets() {
        try {
            InputStream inputStream = getAssets().open("GameGuardianDocument.pdf");
            File outputFile = new File(getCacheDir(), "GameGuardianDocument.pdf");

            FileOutputStream outputStream = new FileOutputStream(outputFile);
            byte[] buffer = new byte[1024];
            int length;

            while ((length = inputStream.read(buffer)) > 0) {
                outputStream.write(buffer, 0, length);
            }

            outputStream.close();
            inputStream.close();

            return outputFile;
        } catch (IOException e) {
            e.printStackTrace();
            Toast.makeText(this, "复制PDF文件失败", Toast.LENGTH_SHORT).show();
            return null;
        }
    }

    /**
     * 打开PDF渲染器
     */
    private void openPdfRenderer(File file) throws IOException {
        parcelFileDescriptor = ParcelFileDescriptor.open(
                file,
                ParcelFileDescriptor.MODE_READ_ONLY
        );
        pdfRenderer = new PdfRenderer(parcelFileDescriptor);
    }

    /**
     * 显示指定页面
     */
    private void showPage(int index) {
        if (pdfRenderer == null) {
            return;
        }

        if (index < 0 || index >= pdfRenderer.getPageCount()) {
            return;
        }

        // 关闭当前页
        if (currentPage != null) {
            currentPage.close();
        }

        // 打开新页
        currentPage = pdfRenderer.openPage(index);

        // 创建位图（可以调整缩放比例来提高清晰度）
        int scale = 2; // 缩放倍数
        Bitmap bitmap = Bitmap.createBitmap(
                currentPage.getWidth() * scale,
                currentPage.getHeight() * scale,
                Bitmap.Config.ARGB_8888
        );

        // 渲染PDF页面到位图
        currentPage.render(
                bitmap,
                null,
                null,
                PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY
        );

        // 显示位图
        imageView.setImageBitmap(bitmap);

        // 更新按钮状态
        updateButtonStates();

        // 显示页码
        setTitle("第 " + (index + 1) + " 页 / 共 " + pdfRenderer.getPageCount() + " 页");
    }

    /**
     * 更新按钮状态
     */
    private void updateButtonStates() {
        if (pdfRenderer == null) {
            return;
        }

        btnPrevious.setEnabled(currentPageIndex > 0);
        btnNext.setEnabled(currentPageIndex < pdfRenderer.getPageCount() - 1);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        closeRenderer();
    }

    /**
     * 关闭渲染器并释放资源
     */
    private void closeRenderer() {
        if (currentPage != null) {
            currentPage.close();
            currentPage = null;
        }

        if (pdfRenderer != null) {
            pdfRenderer.close();
            pdfRenderer = null;
        }

        if (parcelFileDescriptor != null) {
            try {
                parcelFileDescriptor.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
            parcelFileDescriptor = null;
        }
    }
}