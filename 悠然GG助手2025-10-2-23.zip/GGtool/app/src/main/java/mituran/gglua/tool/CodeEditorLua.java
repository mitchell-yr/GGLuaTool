package mituran.gglua.tool;

import static mituran.gglua.tool.luaFormatter.LuaFormatterWrapper.formatLuaFile;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.text.InputType;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.SubMenu;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import org.eclipse.tm4e.core.registry.IThemeSource;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

import io.github.rosemoe.sora.langs.textmate.TextMateColorScheme;
import io.github.rosemoe.sora.langs.textmate.TextMateLanguage;
import io.github.rosemoe.sora.langs.textmate.registry.FileProviderRegistry;
import io.github.rosemoe.sora.langs.textmate.registry.GrammarRegistry;
import io.github.rosemoe.sora.langs.textmate.registry.ThemeRegistry;
import io.github.rosemoe.sora.langs.textmate.registry.model.ThemeModel;
import io.github.rosemoe.sora.langs.textmate.registry.provider.AssetsFileResolver;
import io.github.rosemoe.sora.widget.CodeEditor;
import mituran.gglua.tool.luaFormatter.LuaFormatterWrapper;


public class CodeEditorLua extends AppCompatActivity {

    private ImageButton btnUndo, btnRedo, btnEdit, btnManage,btnCopy,btnPaste,btnFind,btnSave;
    private String path,dirPath;//path：lua脚本路径，dirPath：上级目录路径
    private CodeEditor codeEditor;
    private LinearLayout symbolContainer;

    private List<Template> templates;

    // 定义符号数组 - Lua常用符号
    private String[] symbols = {
            ",", ".","(", ")", "[", "]", "{", "}", "=", "<", ">",
            "+", "-", "*", "/", "%", "^", "#", "..", ":", ";"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_codeeditor_lua);

        // 初始化 Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        // 初始化按钮
        btnUndo = findViewById(R.id.btn_undo);
        btnRedo = findViewById(R.id.btn_redo);
        btnEdit = findViewById(R.id.btn_edit);
        btnManage = findViewById(R.id.btn_manage);
        btnCopy = findViewById(R.id.btn_copy);
        btnPaste = findViewById(R.id.btn_paste);
        btnFind = findViewById(R.id.btn_find);
        btnSave = findViewById(R.id.btn_save);

        // 初始化符号容器
        symbolContainer = findViewById(R.id.symbol_container);

        Bundle bundle = getIntent().getExtras();
        path = bundle.getString("path")+"/code.lua";
        dirPath = bundle.getString("path");
        String codeTextTemp=readFileFromExternalStorage(path);

        codeEditor = findViewById(R.id.editor);
        codeEditor.setText(codeTextTemp);

        try {
            //加载语法高亮
            FileProviderRegistry.getInstance().addFileProvider(
                    new AssetsFileResolver(
                            getApplicationContext().getAssets()
                    )
            );
            var themeRegistry = ThemeRegistry.getInstance();
            var name = "solarized-light";
            var themeAssetsPath = "textmate/" + name + ".json";
            var model = new ThemeModel(
                    IThemeSource.fromInputStream(
                            FileProviderRegistry.getInstance().tryGetInputStream(themeAssetsPath), themeAssetsPath, null
                    ),
                    name
            );
            themeRegistry.loadTheme(model);
            ThemeRegistry.getInstance().setTheme(name);

            GrammarRegistry.getInstance().loadGrammars("textmate/language.json");

            codeEditor.setColorScheme(TextMateColorScheme.create(ThemeRegistry.getInstance()));

            var languageScopeName = "source.lua";
            var language = TextMateLanguage.create(
                    languageScopeName, true
            );
            codeEditor.setEditorLanguage(language);

        } catch (Exception e) {
            throw new RuntimeException(e);
        }
        codeEditor.setPinLineNumber(true);

        // 初始化符号快捷输入栏
        initSymbolBar();

        // 初始化模板数据
        initTemplates();

        // 保存按钮点击事件
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveData(codeEditor.getText().toString(),dirPath,"/code.lua");
                Toast.makeText(CodeEditorLua.this,"保存成功",Toast.LENGTH_SHORT).show();
            }
        });

        //撤销按钮点击事件
        btnUndo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                codeEditor.undo();
            }
        });

        //搜索按钮点击事件
        btnFind.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                codeEditor.beginSearchMode();
            }
        });

        //重做按钮点击事件
        btnRedo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v){
                codeEditor.redo();
            }
        });

        //编辑按钮点击事件 - 显示编辑菜单
        btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showEditMenu(v);
            }
        });

        //复制按钮点击事件
        btnCopy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                codeEditor.copyText();
            }
        });

        //粘贴按钮点击事件
        btnPaste.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                codeEditor.pasteText();
            }
        });

        //管理按钮点击事件 - 显示管理菜单
        btnManage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showManageMenu(v);
            }
        });
    }

    // 初始化符号快捷输入栏
    private void initSymbolBar() {
        for (String symbol : symbols) {
            Button btn = new Button(this);
            btn.setText(symbol);
            btn.setTextColor(Color.WHITE);
            btn.setBackgroundColor(Color.TRANSPARENT);
            btn.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);  // 字体大小到12sp
            btn.setPadding(35, 4, 35, 4);  // padding (左, 上, 右, 下)
            btn.setAllCaps(false);
            btn.setMinHeight(0);
            btn.setMinWidth(0);
            btn.setMinimumHeight(0);
            btn.setMinimumWidth(0);
            btn.setGravity(Gravity.CENTER);

            // 设置按钮背景（可选，添加点击效果）
            TypedValue outValue = new TypedValue();
            getTheme().resolveAttribute(android.R.attr.selectableItemBackground, outValue, true);
            btn.setBackgroundResource(outValue.resourceId);

            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    LinearLayout.LayoutParams.MATCH_PARENT
            );
            params.setMargins(2, 0, 2, 0);//各个按钮间距
            btn.setLayoutParams(params);

            btn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    insertSymbol(symbol);
                }
            });

            symbolContainer.addView(btn);
        }
    }

    // 插入符号到编辑器
    private void insertSymbol(String symbol) {
        // 在光标位置插入符号
        codeEditor.insertText(symbol, symbol.length());
        // 对于某些符号，自动添加配对符号并将光标移到中间
        switch (symbol) {
//            case "function":
//                codeEditor.insertText(" ()\n\nend", 1);
//                //将光标移动到括号中间
//                codeEditor.getCursor().set(
//                        codeEditor.getCursor().getLeftLine(),
//                        codeEditor.getCursor().getLeftColumn() - 10
//                );
//                break;
//            case "if":
//                codeEditor.insertText(" then\n\nend", 11);
//                // 将光标移动到then前面
//                codeEditor.getCursor().set(
//                        codeEditor.getCursor().getLeftLine() - 2,
//                        codeEditor.getCursor().getLeftColumn() - 9
//                );
//                break;
//            case "for":
//                codeEditor.insertText(" do\n\nend", 9);
//                codeEditor.getCursor().set(
//                        codeEditor.getCursor().getLeftLine() - 2,
//                        codeEditor.getCursor().getLeftColumn() - 7
//                );
//                break;
//            case "while":
//                codeEditor.insertText(" do\n\nend", 9);
//                codeEditor.getCursor().set(
//                        codeEditor.getCursor().getLeftLine() - 2,
//                        codeEditor.getCursor().getLeftColumn() - 7
//                );
//                break;
            case "(":
                codeEditor.insertText(")", 1);
                codeEditor.getCursor().set(
                        codeEditor.getCursor().getLeftLine(),
                        codeEditor.getCursor().getLeftColumn() - 1
                );
                break;
            case "[":
                codeEditor.insertText("]", 1);
                codeEditor.getCursor().set(
                        codeEditor.getCursor().getLeftLine(),
                        codeEditor.getCursor().getLeftColumn() - 1
                );
                break;
            case "{":
                codeEditor.insertText("}", 1);
                codeEditor.getCursor().set(
                        codeEditor.getCursor().getLeftLine(),
                        codeEditor.getCursor().getLeftColumn() - 1
                );
                break;
        }
    }

    // 显示编辑菜单
    private void showEditMenu(View anchor) {
        PopupMenu popupMenu = new PopupMenu(this, anchor);

        // 添加菜单项
        popupMenu.getMenu().add(0, 1, 0, "全选");
        popupMenu.getMenu().add(0, 7, 0, "跳转到行");
        popupMenu.getMenu().add(0, 8, 0, "格式化代码");

        // 设置菜单项点击事件
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case 1: // 全选
                        codeEditor.selectAll();
                        break;
                    case 7: // 跳转到行
                        showGotoLineDialog();
                        break;
                    case 8: // 格式化代码
                        formatCode();
                        break;
                }
                return true;
            }
        });

        popupMenu.show();
    }

    // 显示管理菜单
    private void showManageMenu(View anchor) {
        PopupMenu popupMenu = new PopupMenu(this, anchor);

// 添加菜单项
        popupMenu.getMenu().add(0, 1, 0, "导出文件");
        popupMenu.getMenu().add(0, 2, 0, "另存为");
        popupMenu.getMenu().add(0, 3, 0, "导入模板");
        popupMenu.getMenu().add(0, 4, 0, "项目信息");


// 创建"编辑器设置"的子菜单
        SubMenu editorSubMenu = popupMenu.getMenu().addSubMenu(0, 5, 0, "编辑器设置");
        editorSubMenu.add(0, 6, 0, "主题设置");
        editorSubMenu.add(0, 7, 0, "字体大小");
        editorSubMenu.add(0, 8, 0, "显示行号");
        editorSubMenu.add(0, 9, 0, "换行显示");

// 继续添加其他菜单项
        popupMenu.getMenu().add(0, 10, 0, "关于");

// 设置菜单项点击事件
        popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()) {
                    case 1: // 导出文件
                        exportFile();
                        break;
                    case 2: // 另存为
                        saveAs();
                        break;
                    case 3: // 模板
                        importTemplate();
                        break;
                    case 4: // 项目信息
                        showProjectInfo();
                        break;
                    // case 5 已经是子菜单，不需要处理点击事件
                    case 6: // 主题设置
                        showThemeSettings();
                        break;
                    case 7: // 字体大小
                        showFontSizeDialog();
                        break;
                    case 8: // 显示行号
                        toggleLineNumbers();
                        break;
                    case 9: // 自动换行
                        toggleWordWrap();
                        break;
                    case 10: // 关于
                        showAboutDialog();
                        break;
                }
                return true;
            }
        });
        popupMenu.show();
    }

    //导入模板
    private void importTemplate(){
        showTemplateDialog();
    }

    //转跳到行按钮
    private void showGotoLineDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("行号跳转");  // 设置对话框标题

// 创建输入框
        final EditText input = new EditText(this);
        input.setHint("请输入跳转行号");  // 设置提示文字
        input.setInputType(InputType.TYPE_CLASS_NUMBER);  // 设置输入类型为数字

// 设置布局参数
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        input.setLayoutParams(lp);

// 将输入框添加到对话框
        builder.setView(input);

// 设置确定按钮
        builder.setPositiveButton("跳转", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String lineNumber = input.getText().toString().trim();
                if (!lineNumber.isEmpty()) {
                    try {
                        int line = Integer.parseInt(lineNumber);
                        if (line > 0 && line <= codeEditor.getLineCount()) {
                            codeEditor.jumpToLine(line);
                        } else {
                            Toast.makeText(CodeEditorLua.this, "请输入有效的行号", Toast.LENGTH_SHORT).show();
                        }
                    } catch (NumberFormatException e) {
                        Toast.makeText(CodeEditorLua.this, "请输入数字", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

// 设置取消按钮
        builder.setNegativeButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.cancel();  // 关闭对话框
            }
        });

// 创建并显示对话框
        AlertDialog dialog = builder.create();
        dialog.show();

    }

    private void formatCode() {
        // 先保存当前代码
        saveData(codeEditor.getText().toString(), dirPath, "/code.lua");

        // 异步格式化
        LuaFormatterWrapper.formatLuaFileAsync(path, "UTF-8", success -> {
            runOnUiThread(() -> {
                if (success) {
                    // 格式化成功，重新读取文件
                    String tempCode = readFileFromExternalStorage(path);
                    codeEditor.setText(tempCode);
                    Toast.makeText(this, "格式化成功", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "格式化失败，请检查日志", Toast.LENGTH_SHORT).show();
                    Log.e("FormatCode", "格式化失败，路径: " + path);
                }
            });
        });
    }


    private void saveAs() {
        // TODO: 实现另存为功能
        Toast.makeText(this, "另存为功能待实现", Toast.LENGTH_SHORT).show();
    }

    private void exportFile() {
        // TODO: 实现导出文件功能
        Toast.makeText(this, "导出文件功能待实现", Toast.LENGTH_SHORT).show();
    }

    private void showProjectInfo() {
        File file = new File(path);
        String info = "项目路径: " + path + "\n" +
                "项目大小: " + " bytes\n" +
                "最后修改: " + new java.util.Date(file.lastModified());

        new AlertDialog.Builder(this)
                .setTitle("项目信息")
                .setMessage(info)
                .setPositiveButton("确定", null)
                .show();
    }

    private void showEditorSettings() {
        // TODO: 实现编辑器设置对话框
        Toast.makeText(this, "编辑器设置功能待实现", Toast.LENGTH_SHORT).show();
    }

    private void showThemeSettings() {
        String[] themes = {"Solarized Light", "Solarized Dark", "Monokai", "GitHub"};
        new AlertDialog.Builder(this)
                .setTitle("选择主题")
                .setItems(themes, (dialog, which) -> {
                    // TODO: 实现主题切换
//                    Toast.makeText(this, "选择了: " + themes[which], Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void showFontSizeDialog() {
        String[] sizes = {"12", "14", "16", "18", "20", "22", "24"};
        new AlertDialog.Builder(this)
                .setTitle("选择字体大小")
                .setItems(sizes, (dialog, which) -> {
                    float size = Float.parseFloat(sizes[which]);
                    codeEditor.setTextSize(size);
                })
                .show();
    }

    private void toggleLineNumbers() {
        codeEditor.setLineNumberEnabled(!codeEditor.isLineNumberEnabled());
        Toast.makeText(this,
                codeEditor.isLineNumberEnabled() ? "显示行号" : "隐藏行号",
                Toast.LENGTH_SHORT).show();
    }

    private void toggleWordWrap() {
        codeEditor.setWordwrap(!codeEditor.isWordwrap());
        Toast.makeText(this,
                codeEditor.isWordwrap() ? "启用显示换行" : "禁用显示换行",
                Toast.LENGTH_SHORT).show();
    }

    private void showAboutDialog() {
        new AlertDialog.Builder(this)
                .setTitle("关于")
                .setMessage("Lua代码编辑器")
                .setPositiveButton("确定", null)
                .show();
    }

    @Override
    public void onBackPressed() {
        // 显示退出确认对话框
        showExitDialog();
    }

    private void showExitDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("退出应用");
        builder.setMessage("退出后未保存的内容改动将无效，您确定要退出吗?");

        builder.setPositiveButton("保存并退出", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                saveDataAndExit(codeEditor.getText().toString(),dirPath,"/code.lua");
            }
        });
        builder.setNegativeButton("直接退出", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                finish();
            }
        });
        builder.setNeutralButton("取消", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                dialog.dismiss();
            }
        });

        builder.show();
    }

    //模板导入初始化
    private void initTemplates() {
        templates = new ArrayList<>();

        File templateDir = new File(Environment.getExternalStorageDirectory(),"/GGtool/templates/");
        //Toast.makeText(this, templateDir.getAbsolutePath(), Toast.LENGTH_SHORT).show();
        // 检查目录是否存在
        if (!templateDir.exists() || !templateDir.isDirectory()) {
            Toast.makeText(this, "模板目录不存在", Toast.LENGTH_SHORT).show();
            return;
        }

        // 获取目录下所有json文件
        File[] files = templateDir.listFiles();
        if (files == null || files.length == 0) {
            Toast.makeText(this, "模板目录为空", Toast.LENGTH_SHORT).show();
            return;
        }

        // 遍历读取模板文件
        for (File file : files) {
            if (file.isFile() && file.getName().endsWith(".json")) {
                try {
                    Template template = loadTemplateFromFile(file);
                    if (template != null) {
                        templates.add(template);
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    Toast.makeText(this, "读取模板失败: " + file.getName(), Toast.LENGTH_SHORT).show();
                }
            }
        }

        if (templates.isEmpty()) {
            Toast.makeText(this, "未找到有效的模板文件", Toast.LENGTH_SHORT).show();
        }
    }

    private Template loadTemplateFromFile(File file) {
        FileInputStream fis = null;
        try {
            // 读取文件内容
            fis = new FileInputStream(file);
            byte[] buffer = new byte[(int) file.length()];
            fis.read(buffer);
            String jsonContent = new String(buffer, "UTF-8");

            // 解析JSON
            JSONObject jsonObject = new JSONObject(jsonContent);
            String version = jsonObject.getString("version");
            String code = jsonObject.getString("code");

            // 获取模板名称（去掉.json后缀）
            String templateName = file.getName().replace(".json", "");

            return new Template(templateName, version, code);

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (fis != null) {
                try {
                    fis.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    private void showTemplateDialog() {
        TemplateImportDialog dialog = new TemplateImportDialog(this, templates);
        dialog.setOnTemplateSelectedListener(new TemplateImportDialog.OnTemplateSelectedListener() {
            @Override
            public void onTemplateSelected(Template template, TemplateImportDialog.InsertPosition position) {
                insertTemplate(template, position);
            }
        });
        dialog.show();
    }

    private void insertTemplate(Template template, TemplateImportDialog.InsertPosition position) {
        String currentText = codeEditor.getText().toString();
        String templateContent = template.getContent();

        if (position == TemplateImportDialog.InsertPosition.CURSOR) {
            
            // 在光标处插入
            try {
                codeEditor.insertText(templateContent, 1);
                codeEditor.getCursor().set(
                        codeEditor.getCursor().getLeftLine(),
                        codeEditor.getCursor().getLeftColumn() - 1
                );
            } catch (Exception e) {
                Toast.makeText(this,"插入失败，请确保插件正常",Toast.LENGTH_SHORT).show();
                throw new RuntimeException(e);
            }
        } else {
            // 在头部插入
            String newText = templateContent + "\n" + currentText;
            codeEditor.setText(newText);
            //codeEditor.setSelection(0);
        }

//        Toast.makeText(this,
//                "已插入模板: " + template.getName() + " 到" + position.getDisplayName(),
//                Toast.LENGTH_SHORT).show();
    }

    private void saveDataAndExit(String textToWrite,String folderName,String fileName) {
        saveData(textToWrite, folderName, fileName);
        finish();
    }

    private void saveData(String textToWrite,String folderName,String fileName) {
        writeToFile( textToWrite, folderName, fileName);
    }

    //文本文件读取
    public String readFileFromExternalStorage(String filePath) {
        if (!Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            return null;
        }

        StringBuilder stringBuilder = new StringBuilder();
        try {
            File file = new File(filePath);
            FileInputStream fileInputStream = new FileInputStream(file);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(fileInputStream));
            String line;
            if((line = bufferedReader.readLine()) != null){
                stringBuilder.append(line);
                while ((line = bufferedReader.readLine()) != null) {
                    stringBuilder.append("\n");
                    stringBuilder.append(line);
                }
            }

            bufferedReader.close();
            fileInputStream.close();
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        return stringBuilder.toString();
    }

    //写入文件
    private void writeToFile(String textToWrite,String folderName,String fileName) {
        try {
            File file = new File(folderName, fileName);
            FileOutputStream fos = new FileOutputStream(file);
            fos.write(textToWrite.getBytes());
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //模板数据类
    public class Template {
        private String name;
        private String version;
        private String content; // 模板内容

        public Template(String name, String version, String content) {
            this.name = name;
            this.version = version;
            this.content = content;
        }

        public String getName() {
            return name;
        }

        public String getVersion() {
            return version;
        }

        public String getContent() {
            return content;
        }

        @Override
        public String toString() {
            return name + " (v" + version + ")";
        }
    }
    public class TemplateImportDialog {

        public interface OnTemplateSelectedListener {
            void onTemplateSelected(Template template, InsertPosition position);
        }

        public enum InsertPosition {
            CURSOR("光标处插入"),
            HEAD("头部插入");

            private String displayName;

            InsertPosition(String displayName) {
                this.displayName = displayName;
            }

            public String getDisplayName() {
                return displayName;
            }
        }

        private Context context;
        private List<Template> templates;
        private OnTemplateSelectedListener listener;

        public TemplateImportDialog(Context context, List<Template> templates) {
            this.context = context;
            this.templates = templates;
        }

        public void setOnTemplateSelectedListener(OnTemplateSelectedListener listener) {
            this.listener = listener;
        }

        public void show() {
            // 创建模板名称数组
            String[] templateNames = new String[templates.size()];
            for (int i = 0; i < templates.size(); i++) {
                templateNames[i] = templates.get(i).toString();
            }

            // 显示模板选择对话框
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("选择模板");
            builder.setItems(templateNames, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    Template selectedTemplate = templates.get(which);
                    showPositionDialog(selectedTemplate);
                }
            });
            builder.setNegativeButton("取消", null);
            builder.show();
        }

        private void showPositionDialog(final Template template) {
            String[] positions = {
                    InsertPosition.CURSOR.getDisplayName(),
                    InsertPosition.HEAD.getDisplayName()
            };

            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            builder.setTitle("选择插入位置");
            builder.setItems(positions, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                    InsertPosition position = (which == 0) ?
                            InsertPosition.CURSOR : InsertPosition.HEAD;

                    if (listener != null) {
                        listener.onTemplateSelected(template, position);
                    }
                }
            });
            builder.setNegativeButton("取消", null);
            builder.show();
        }
    }
}