package mituran.gglua.tool;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import io.noties.markwon.Markwon;
import java.util.ArrayList;
import java.util.List;

public class EncryptTutorialActivity extends AppCompatActivity {

    private DrawerLayout drawerLayout;
    private LinearLayout contentContainer;
    private TextView tvCurrentChapter;
    private TextView tvChapterTitle;
    private TextView tvChapterSubtitle;
    private ProgressBar chapterProgress;
    private FloatingActionButton fabNext;
    private RecyclerView rvChapters;

    private List<EncryptTutorialChapter> chapters;
    private int currentChapterIndex = 0;
    private ChapterAdapter chapterAdapter;
    private Markwon markwon;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_encrypt_tutorial);

        initViews();
        initMarkwon();
        initChapters();
        setupRecyclerView();
        setupListeners();

        // 显示第一章
        displayChapter(0);
    }

    private void initViews() {
        drawerLayout = findViewById(R.id.tutorial_drawer_layout);
        contentContainer = findViewById(R.id.tutorial_content_container);
        tvCurrentChapter = findViewById(R.id.tv_current_chapter);
        tvChapterTitle = findViewById(R.id.tv_chapter_title);
        tvChapterSubtitle = findViewById(R.id.tv_chapter_subtitle);
        chapterProgress = findViewById(R.id.chapter_progress);
        fabNext = findViewById(R.id.fab_next_chapter);
        rvChapters = findViewById(R.id.rv_chapters);

        ImageView ivBack = findViewById(R.id.iv_back);
        ImageView ivMenu = findViewById(R.id.iv_menu);

        ivBack.setOnClickListener(v -> finish());
        ivMenu.setOnClickListener(v -> {
            if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
                drawerLayout.closeDrawer(GravityCompat.END);
            } else {
                drawerLayout.openDrawer(GravityCompat.END);
            }
        });
    }

    private void initMarkwon() {
        markwon = Markwon.create(this);
    }

    private void initChapters() {
        chapters = new ArrayList<>();

        // 第一章：基础概念
        EncryptTutorialChapter chapter1 = new EncryptTutorialChapter(1, "基础概念",
                "了解Lua脚本加密的基本原理", "了解基本原理");
        chapter1.addSection(new EncryptTutorialChapter.Section("什么是Lua脚本加密",
                "# 什么是Lua脚本加密\n\n" +
                        "Lua脚本加密是指对Lua源代码进行**加密处理**，使其不易被他人阅读和修改。\n\n" +
                        "## 为什么需要加密\n" +
                        "- 保护知识产权\n" +
                        "- 防止代码被恶意修改\n" +
                        "- 保护商业机密\n\n" +
                        "```lua\n" +
                        "-- 原始代码\n" +
                        "function hello()\n" +
                        "    print(\"Hello World\")\n" +
                        "end\n" +
                        "```"));

        chapter1.addSection(new EncryptTutorialChapter.Section("加密的类型",
                "## 常见的加密类型\n\n" +
                        "### 1. 字节码编译\n" +
                        "将Lua源码编译成字节码，增加阅读难度。\n\n" +
                        "### 2. 字符串混淆\n" +
                        "对代码中的字符串进行编码处理。\n\n" +
                        "### 3. 控制流混淆\n" +
                        "打乱代码执行顺序，增加分析难度。\n\n" +
                        "### 4. 自定义加密\n" +
                        "使用自定义算法对代码进行加密。"));

        chapters.add(chapter1);

        // 第二章：字节码编译
        EncryptTutorialChapter chapter2 = new EncryptTutorialChapter(2, "字节码编译",
                "学习如何将Lua脚本编译为字节码", "编译为字节码");
        chapter2.addSection(new EncryptTutorialChapter.Section("使用luac编译",
                "# 使用luac编译器\n\n" +
                        "luac是Lua官方提供的编译器，可以将`.lua`文件编译为字节码。\n\n" +
                        "## 基本用法\n" +
                        "```bash\n" +
                        "luac -o output.luac input.lua\n" +
                        "```\n\n" +
                        "## 参数说明\n" +
                        "- `-o`: 指定输出文件\n" +
                        "- `-s`: 去除调试信息\n" +
                        "- `-p`: 只进行语法检查"));

        chapter2.addSection(new EncryptTutorialChapter.Section("字节码格式",
                "## Lua字节码格式\n\n" +
                        "字节码文件包含以下部分：\n\n" +
                        "1. **文件头** - 包含版本信息\n" +
                        "2. **函数原型** - 函数定义\n" +
                        "3. **常量表** - 存储常量数据\n" +
                        "4. **指令序列** - 实际的字节码指令\n\n" +
                        "```\n" +
                        "1B 4C 75 61  // Lua签名\n" +
                        "53 00 19 93  // 版本号\n" +
                        "...\n" +
                        "```"));

        chapters.add(chapter2);

        // 第三章：字符串混淆
        EncryptTutorialChapter chapter3 = new EncryptTutorialChapter(3, "字符串混淆",
                "掌握字符串混淆技术", "字符串混淆");
        chapter3.addSection(new EncryptTutorialChapter.Section("Base64编码",
                "# Base64编码\n\n" +
                        "```lua\n" +
                        "-- 编码函数\n" +
                        "function base64_encode(data)\n" +
                        "    local b64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'\n" +
                        "    return ((data:gsub('.', function(x)\n" +
                        "        local r,b='',x:byte()\n" +
                        "        for i=8,1,-1 do r=r..(b%2^i-b%2^(i-1)>0 and '1' or '0') end\n" +
                        "        return r\n" +
                        "    end)..'0000'):gsub('%d%d%d?%d?%d?%d?', function(x)\n" +
                        "        if (#x < 6) then return '' end\n" +
                        "        local c=0\n" +
                        "        for i=1,6 do c=c+(x:sub(i,i)=='1' and 2^(6-i) or 0) end\n" +
                        "        return b64:sub(c+1,c+1)\n" +
                        "    end)..({ '', '==', '=' })[#data%3+1])\n" +
                        "end\n" +
                        "```"));

        chapters.add(chapter3);

        // 第四章：高级加密
        EncryptTutorialChapter chapter4 = new EncryptTutorialChapter(4, "高级加密技术",
                "学习高级加密和混淆技术", "高级技术");
        chapter4.addSection(new EncryptTutorialChapter.Section("控制流混淆",
                "# 控制流混淆\n\n" +
                        "通过改变代码的执行顺序来增加分析难度。\n\n" +
                        "## 示例\n" +
                        "```lua\n" +
                        "-- 原始代码\n" +
                        "if condition then\n" +
                        "    doSomething()\n" +
                        "else\n" +
                        "    doOtherthing()\n" +
                        "end\n\n" +
                        "-- 混淆后\n" +
                        "local jump = condition and 1 or 2\n" +
                        "local actions = {\n" +
                        "    [1] = doSomething,\n" +
                        "    [2] = doOtherthing\n" +
                        "}\n" +
                        "actions[jump]()\n" +
                        "```"));

        chapters.add(chapter4);

        // 第五章：实战应用
        EncryptTutorialChapter chapter5 = new EncryptTutorialChapter(5, "实战应用",
                "将所学知识应用到实际项目", "实战项目");
        chapter5.addSection(new EncryptTutorialChapter.Section("完整加密方案",
                "# 完整的加密方案\n\n" +
                        "## 步骤\n" +
                        "1. **预处理** - 移除注释和格式化\n" +
                        "2. **字符串混淆** - 对所有字符串进行编码\n" +
                        "3. **变量重命名** - 将变量名改为无意义字符\n" +
                        "4. **控制流混淆** - 打乱执行顺序\n" +
                        "5. **字节码编译** - 编译为字节码\n" +
                        "6. **自定义加密** - 使用自定义算法加密\n\n" +
                        "## 注意事项\n" +
                        "- 保留原始代码备份\n" +
                        "- 测试加密后的功能\n" +
                        "- 平衡安全性和性能"));

        chapters.add(chapter5);
    }

    private void setupRecyclerView() {
        chapterAdapter = new ChapterAdapter(this, chapters);
        rvChapters.setLayoutManager(new LinearLayoutManager(this));
        rvChapters.setAdapter(chapterAdapter);

        chapterAdapter.setOnChapterClickListener((chapter, position) -> {
            displayChapter(position);
            drawerLayout.closeDrawer(GravityCompat.END);
        });
    }

    private void setupListeners() {
        fabNext.setOnClickListener(v -> {
            if (currentChapterIndex < chapters.size() - 1) {
                displayChapter(currentChapterIndex + 1);
            } else {
                Toast.makeText(this, "已经是最后一章了", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void displayChapter(int index) {
        if (index < 0 || index >= chapters.size()) return;

        currentChapterIndex = index;
        EncryptTutorialChapter chapter = chapters.get(index);

        // 更新UI
        tvCurrentChapter.setText(String.format("第 %d 章 / 共 %d 章",
                chapter.getChapterNumber(), chapters.size()));
        tvChapterTitle.setText(String.format("第%s章：%s",
                convertToChineseNumber(chapter.getChapterNumber()), chapter.getTitle()));
        tvChapterSubtitle.setText(chapter.getSubtitle());

        // 更新进度
        int progress = (int) ((index + 1) * 100.0 / chapters.size());
        chapterProgress.setProgress(progress);

        // 清除旧内容（保留标题卡片）
        while (contentContainer.getChildCount() > 1) {
            contentContainer.removeViewAt(1);
        }

        // 添加章节内容
        for (EncryptTutorialChapter.Section section : chapter.getSections()) {
            addMarkdownSection(section);
        }

        // 标记章节为已完成
        chapter.setCompleted(true);
        chapterAdapter.notifyItemChanged(index);

        // 更新FAB状态
        if (index == chapters.size() - 1) {
            fabNext.setImageResource(R.drawable.ic_check);
        } else {
            fabNext.setImageResource(R.drawable.ic_arrow_forward);
        }

        // 滚动到顶部
        findViewById(R.id.tutorial_scroll_view).scrollTo(0, 0);
    }

    private void addMarkdownSection(EncryptTutorialChapter.Section section) {
        View sectionView = LayoutInflater.from(this)
                .inflate(R.layout.item_encrypt_tutorial_markdown_section, contentContainer, false);

        TextView tvTitle = sectionView.findViewById(R.id.tv_section_title);
        TextView tvContent = sectionView.findViewById(R.id.tv_markdown_content);

        if (section.getTitle() != null && !section.getTitle().isEmpty()) {
            tvTitle.setText(section.getTitle());
            tvTitle.setVisibility(View.VISIBLE);
        }

        // 使用Markwon渲染Markdown
        markwon.setMarkdown(tvContent, section.getMarkdownContent());

        contentContainer.addView(sectionView);
    }

    private String convertToChineseNumber(int number) {
        String[] chinese = {"零", "一", "二", "三", "四", "五", "六", "七", "八", "九", "十"};
        if (number <= 10) {
            return chinese[number];
        }
        return String.valueOf(number);
    }
}