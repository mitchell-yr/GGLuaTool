package mituran.gglua.tool;

import java.util.ArrayList;
import java.util.List;

public class EncryptTutorialChapter {
    private int chapterNumber;
    private String title;
    private String subtitle;
    private String description;
    private boolean isCompleted;
    private List<Section> sections;

    public static class Section {
        private String title;
        private String markdownContent;

        public Section(String title, String markdownContent) {
            this.title = title;
            this.markdownContent = markdownContent;
        }

        // Getters and setters
        public String getTitle() { return title; }
        public void setTitle(String title) { this.title = title; }
        public String getMarkdownContent() { return markdownContent; }
        public void setMarkdownContent(String content) { this.markdownContent = content; }
    }

    public EncryptTutorialChapter(int chapterNumber, String title, String subtitle, String description) {
        this.chapterNumber = chapterNumber;
        this.title = title;
        this.subtitle = subtitle;
        this.description = description;
        this.isCompleted = false;
        this.sections = new ArrayList<>();
    }

    // Getters and setters
    public int getChapterNumber() { return chapterNumber; }
    public String getTitle() { return title; }
    public String getSubtitle() { return subtitle; }
    public String getDescription() { return description; }
    public boolean isCompleted() { return isCompleted; }
    public void setCompleted(boolean completed) { isCompleted = completed; }
    public List<Section> getSections() { return sections; }
    public void setSections(List<Section> sections) { this.sections = sections; }

    public void addSection(Section section) {
        sections.add(section);
    }
}