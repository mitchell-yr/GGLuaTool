package mituran.gglua.tool.licenseModel;

public class LicenseModel {
    private String libraryName;
    private String author;
    private String libraryUrl;
    private String licenseType;
    private String licenseText;

    public LicenseModel(String libraryName, String author, String libraryUrl,
                        String licenseType, String licenseText) {
        this.libraryName = libraryName;
        this.author = author;
        this.libraryUrl = libraryUrl;
        this.licenseType = licenseType;
        this.licenseText = licenseText;
    }

    // Getters and Setters
    public String getLibraryName() { return libraryName; }
    public void setLibraryName(String libraryName) { this.libraryName = libraryName; }

    public String getAuthor() { return author; }
    public void setAuthor(String author) { this.author = author; }

    public String getLibraryUrl() { return libraryUrl; }
    public void setLibraryUrl(String libraryUrl) { this.libraryUrl = libraryUrl; }

    public String getLicenseType() { return licenseType; }
    public void setLicenseType(String licenseType) { this.licenseType = licenseType; }

    public String getLicenseText() { return licenseText; }
    public void setLicenseText(String licenseText) { this.licenseText = licenseText; }
}