package mituran.gglua.tool;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.RotateAnimation;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.button.MaterialButton;
import com.google.android.material.chip.Chip;
import com.google.android.material.navigation.NavigationView;

import java.util.ArrayList;
import java.util.List;

import mituran.gglua.tool.licenseModel.OpenSourceLicenseActivity;

public class HomeFragment extends Fragment implements NavigationView.OnNavigationItemSelectedListener {
    private DrawerLayout drawerLayout;
    private NavigationView navigationView;
    private Toolbar toolbar;
    private ViewPager2 viewPager;
    private LinearLayout indicatorLayout;
    private BannerAdapter bannerAdapter;
    private Handler autoScrollHandler = new Handler(Looper.getMainLooper());
    private Runnable autoScrollRunnable;
    private int currentPage = 0;

    // 卡片视图
    private CardView card_downloadGG, card2, card3, card4;

    //GG下载卡片按钮
    private Button btn_downloadGG;


    Button btnUnluac,btnTdecompile,btnGGDecompile;
    // 反编译工具类型
    private enum DecompilerType {
        UNLUAC,
        TDECOMPILE,
        GG_MODIFIER
    }


    private ActivityResultLauncher<String> filePickerLauncher;
    //加解密card2用
    private Dialog currentDialog;
    //加密教程
    private Button btnEncryptTutorial;
    private DecompilerType currentDecompilerType;


    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // 初始化视图
        drawerLayout = view.findViewById(R.id.home_drawer_layout);
        navigationView = view.findViewById(R.id.home_nav_view);
        toolbar = view.findViewById(R.id.home_toolbar);
        viewPager = view.findViewById(R.id.viewPager);
        indicatorLayout = view.findViewById(R.id.indicatorLayout);

        // 初始化卡片
        card_downloadGG = view.findViewById(R.id.card1);
        card2 = view.findViewById(R.id.card2);
        card3 = view.findViewById(R.id.card3);
        card4 = view.findViewById(R.id.card4);

        //GG下载卡片的按钮
        btn_downloadGG = view.findViewById(R.id.btn_downloadGG);
        // Unluac按钮
         btnUnluac = view.findViewById(R.id.btn_unluac);
        // TDECOMPILE按钮
         btnTdecompile = view.findViewById(R.id.btn_tdecompile);
        // GG修改器反编译按钮
         btnGGDecompile = view.findViewById(R.id.btn_gg_decompile);
         //加密教程
         btnEncryptTutorial = view.findViewById(R.id.btn_encrypt_tutorial);


        // 设置工具栏
        ((AppCompatActivity) getActivity()).setSupportActionBar(toolbar);

        // 设置导航视图监听器
        navigationView.setNavigationItemSelectedListener(this);

        // 设置轮播图
        setupBanner();

        // 设置卡片点击事件
        setupCardClickListeners();

        // 初始化文件选择器
        initializeFilePicker();

        // 设置unluac反编译按钮点击事件
        Button btnUnluac = view.findViewById(R.id.btn_unluac);

        return view;
    }

    private void setupBanner() {
        // 准备轮播图数据（这里使用示例图片，实际使用时替换为真实图片）
        List<Integer> bannerImages = new ArrayList<>();
        bannerImages.add(R.drawable.ic_launcher_background); // 替换为真实图片
        bannerImages.add(R.drawable.ic_launcher_background);
        bannerImages.add(R.drawable.ic_launcher_background);

        // 设置适配器
        bannerAdapter = new BannerAdapter(bannerImages);
        bannerAdapter.setOnBannerClickListener(position -> {
            Toast.makeText(getContext(), "点击了第 " + (position + 1) + " 张图片", Toast.LENGTH_SHORT).show();
        });
        viewPager.setAdapter(bannerAdapter);

        // 设置指示器
        setupIndicators(bannerImages.size());

        // 设置页面切换监听
        viewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                currentPage = position;
                updateIndicators(position);
            }
        });

        // 设置自动轮播
        setupAutoScroll(bannerImages.size());
    }

    private void setupIndicators(int count) {
        indicatorLayout.removeAllViews();
        for (int i = 0; i < count; i++) {
            View indicator = new View(getContext());
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
                    20, 20
            );
            params.setMargins(8, 0, 8, 0);
            indicator.setLayoutParams(params);
            indicator.setBackgroundResource(R.drawable.banner_indicator_selector);
            indicator.setSelected(i == 0);
            indicatorLayout.addView(indicator);
        }
    }

    private void updateIndicators(int position) {
        for (int i = 0; i < indicatorLayout.getChildCount(); i++) {
            indicatorLayout.getChildAt(i).setSelected(i == position);
        }
    }

    private void setupAutoScroll(int pageCount) {
        autoScrollRunnable = new Runnable() {
            @Override
            public void run() {
                if (currentPage == pageCount - 1) {
                    currentPage = 0;
                } else {
                    currentPage++;
                }
                viewPager.setCurrentItem(currentPage, true);
                autoScrollHandler.postDelayed(this, 3000); // 3秒切换一次
            }
        };
    }

    private void setupCardClickListeners() {
        card_downloadGG.setOnClickListener(v -> {
            //点击下载GG卡片
        });
        btn_downloadGG.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    // 创建Intent，设置动作为ACTION_VIEW
                    Intent intent = new Intent(Intent.ACTION_VIEW);
                    // 设置要打开的URL
                    intent.setData(Uri.parse("https://gameguardian.net/forum/files/file/2-gameguardian/"));
                    // 启动Activity
                    startActivity(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        // Unluac按钮
        if (btnUnluac != null) {
            btnUnluac.setOnClickListener(v -> {
                currentDecompilerType = DecompilerType.UNLUAC;
                showUnluacDialog();
            });
        }

        // TDECOMPILE按钮
        if (btnTdecompile != null) {
            btnTdecompile.setOnClickListener(v -> {
                currentDecompilerType = DecompilerType.TDECOMPILE;
                showTdecompileDialog();
            });
        }

        // GG修改器反编译按钮
        if (btnGGDecompile != null) {
            btnGGDecompile.setOnClickListener(v -> {
                currentDecompilerType = DecompilerType.GG_MODIFIER;
                Toast.makeText(getContext(), "GG修改器反编译功能开发中...", Toast.LENGTH_SHORT).show();
            });
        }
        //加密教程
        if (btnEncryptTutorial != null) {
            btnEncryptTutorial.setOnClickListener(v -> {
                Intent intent = new Intent();
                intent.setClass(getContext(),EncryptTutorialActivity.class);
                startActivity(intent);
            });
        }
        card2.setOnClickListener(v -> {
            // 在这里处理卡片2的点击事件
        });

        card3.setOnClickListener(v -> {
            // 在这里处理卡片3的点击事件
        });

        card4.setOnClickListener(v -> {
            // 在这里处理卡片4的点击事件
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        // 开始自动轮播
        autoScrollHandler.postDelayed(autoScrollRunnable, 3000);
    }

    @Override
    public void onPause() {
        super.onPause();
        // 停止自动轮播
        autoScrollHandler.removeCallbacks(autoScrollRunnable);
    }

    @Override
    public void onCreateOptionsMenu(@NonNull Menu menu, @NonNull MenuInflater inflater) {
        inflater.inflate(R.menu.home_toolbar_menu, menu);
        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == R.id.action_more) {
            if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
                drawerLayout.closeDrawer(GravityCompat.END);
            } else {
                drawerLayout.openDrawer(GravityCompat.END);
            }
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.nav_home_donate) {
            // 处理捐赠
        } else if (id == R.id.nav_home_settings) {
            // 处理设置
        } else if (id == R.id.nav_home_update) {
            // 处理更新
        } else if (id == R.id.nav_home_openAddress) {
            // 处理打开地址
        } else if (id == R.id.nav_home_openLicense) {
            // 处理开源许可
            // 启动许可证界面
            Intent intent = new Intent(getContext(), OpenSourceLicenseActivity.class);
            startActivity(intent);
        }

        drawerLayout.closeDrawer(GravityCompat.END);
        return true;
    }

    public boolean handleBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.END)) {
            drawerLayout.closeDrawer(GravityCompat.END);
            return true;
        }
        return false;
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        autoScrollHandler.removeCallbacks(autoScrollRunnable);
    }

    /**
     * 初始化文件选择器
     */
    private void initializeFilePicker() {
        filePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.GetContent(),
                uri -> {
                    if (uri != null) {
                        handleSelectedFile(uri);
                    }
                }
        );
    }
    /**
     * 显示Unluac弹窗
     */
    private void showUnluacDialog() {
        currentDialog = new Dialog(getContext());
        currentDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        currentDialog.setContentView(R.layout.dialog_unluac);

        setupDialogWindow(currentDialog);
        initializeUnluacDialogViews();

        currentDialog.show();
        addDialogAnimation(currentDialog);
    }
    /**
     * 显示TDECOMPILE弹窗
     */
    private void showTdecompileDialog() {
        currentDialog = new Dialog(getContext());
        currentDialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        currentDialog.setContentView(R.layout.dialog_tdecompile);

        setupDialogWindow(currentDialog);
        initializeTdecompileDialogViews();

        currentDialog.show();
        addDialogAnimation(currentDialog);
    }

    /**
     * 设置弹窗窗口属性
     */
    private void setupDialogWindow(Dialog dialog) {
        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            int width = (int) (getResources().getDisplayMetrics().widthPixels * 0.90);
            dialog.getWindow().setLayout(width, LinearLayout.LayoutParams.WRAP_CONTENT);
        }
    }

    /**
     * 初始化Unluac弹窗视图
     */
    private void initializeUnluacDialogViews() {
        LinearLayout llIntroHeader = currentDialog.findViewById(R.id.ll_intro_header);
        CardView cvIntroContent = currentDialog.findViewById(R.id.cv_intro_content);
        ImageView ivExpandIcon = currentDialog.findViewById(R.id.iv_expand_icon);
        MaterialButton btnSelectFromProject = currentDialog.findViewById(R.id.btn_select_from_project);
        MaterialButton btnSelectCustomScript = currentDialog.findViewById(R.id.btn_select_custom_script);
        TextView tvCancel = currentDialog.findViewById(R.id.tv_cancel);

        // 折叠/展开功能
        llIntroHeader.setOnClickListener(v -> {
            toggleExpandableView(cvIntroContent, ivExpandIcon);
        });

        // 从项目列表选择
        btnSelectFromProject.setOnClickListener(v -> {
            currentDialog.dismiss();
            showProjectListDialog(DecompilerType.UNLUAC);
        });

        // 选择自定义脚本
        btnSelectCustomScript.setOnClickListener(v -> {
            openFilePicker();
        });

        // 取消按钮
        tvCancel.setOnClickListener(v -> {
            currentDialog.dismiss();
        });
    }

    /**
     * 初始化TDECOMPILE弹窗视图
     */
    private void initializeTdecompileDialogViews() {
        // 获取视图组件
        LinearLayout llIntroHeader = currentDialog.findViewById(R.id.ll_tdecompile_intro_header);
        CardView cvIntroContent = currentDialog.findViewById(R.id.cv_tdecompile_intro_content);
        ImageView ivExpandIcon = currentDialog.findViewById(R.id.iv_tdecompile_expand_icon);
        MaterialButton btnSelectFromProject = currentDialog.findViewById(R.id.btn_tdecompile_select_from_project);
        MaterialButton btnSelectCustom = currentDialog.findViewById(R.id.btn_tdecompile_select_custom);
        MaterialButton btnBatch = currentDialog.findViewById(R.id.btn_tdecompile_batch);
        TextView tvCancel = currentDialog.findViewById(R.id.tv_tdecompile_cancel);



        // 折叠/展开功能
        llIntroHeader.setOnClickListener(v -> {
            toggleExpandableView(cvIntroContent, ivExpandIcon);
        });

        // 从项目列表选择
        btnSelectFromProject.setOnClickListener(v -> {
            currentDialog.dismiss();
            showProjectListDialog(DecompilerType.TDECOMPILE);
        });

        // 选择自定义脚本
        btnSelectCustom.setOnClickListener(v -> {
            openFilePicker();
        });

        // 批量处理
        btnBatch.setOnClickListener(v -> {
            currentDialog.dismiss();
            showBatchProcessDialog();
        });



        // 取消按钮
        tvCancel.setOnClickListener(v -> {
            currentDialog.dismiss();
        });
    }

    /**
     * 切换可展开视图
     */
    private void toggleExpandableView(View contentView, ImageView expandIcon) {
        if (contentView.getVisibility() == View.GONE) {
            expandView(contentView);
            rotateIcon(expandIcon, 0, 180);
        } else {
            collapseView(contentView);
            rotateIcon(expandIcon, 180, 0);
        }
    }

    /**
     * 展开视图动画
     */
    private void expandView(View view) {
        view.setVisibility(View.VISIBLE);
        Animation expandAnimation = AnimationUtils.loadAnimation(getContext(), android.R.anim.fade_in);
        expandAnimation.setDuration(300);
        view.startAnimation(expandAnimation);
    }

    /**
     * 折叠视图动画
     */
    private void collapseView(View view) {
        Animation collapseAnimation = AnimationUtils.loadAnimation(getContext(), android.R.anim.fade_out);
        collapseAnimation.setDuration(300);
        collapseAnimation.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {}

            @Override
            public void onAnimationEnd(Animation animation) {
                view.setVisibility(View.GONE);
            }

            @Override
            public void onAnimationRepeat(Animation animation) {}
        });
        view.startAnimation(collapseAnimation);
    }

    /**
     * 旋转图标动画
     */
    private void rotateIcon(ImageView icon, float fromDegree, float toDegree) {
        RotateAnimation rotate = new RotateAnimation(
                fromDegree, toDegree,
                Animation.RELATIVE_TO_SELF, 0.5f,
                Animation.RELATIVE_TO_SELF, 0.5f
        );
        rotate.setDuration(300);
        rotate.setFillAfter(true);
        icon.startAnimation(rotate);
    }

    /**
     * 添加弹窗显示动画
     */
    private void addDialogAnimation(Dialog dialog) {
        if (dialog.getWindow() != null) {
            dialog.getWindow().getAttributes().windowAnimations = R.style.DialogAnimation;
        }
    }

    /**
     * 打开文件选择器
     */
    private void openFilePicker() {
        Log.d("TAG", "Opening file picker for: " + currentDecompilerType);
        filePickerLauncher.launch("*/*");
    }

    /**
     * 处理选中的文件
     */
    private void handleSelectedFile(Uri fileUri) {
        String fileName = getFileName(fileUri);

        // 检查文件扩展名
        if (fileName != null && (fileName.toLowerCase().endsWith(".lua") ||
                fileName.toLowerCase().endsWith(".luac"))) {

            if (currentDialog != null) {
                currentDialog.dismiss();
            }

            String message = String.format("已选择文件: %s\n使用工具: %s",
                    fileName, getDecompilerName(currentDecompilerType));
            Toast.makeText(getContext(), message, Toast.LENGTH_LONG).show();

            // 根据不同的反编译工具处理
            switch (currentDecompilerType) {
                case UNLUAC:
                    processUnluacDecompile(fileUri);
                    break;
                case TDECOMPILE:
                    processTdecompileDecompile(fileUri);
                    break;
                case GG_MODIFIER:
                    processGGModifierDecompile(fileUri);
                    break;
            }
        } else {
            Toast.makeText(getContext(), "请选择.lua或.luac文件", Toast.LENGTH_SHORT).show();
        }
    }

    /**
     * 获取反编译工具名称
     */
    private String getDecompilerName(DecompilerType type) {
        switch (type) {
            case UNLUAC:
                return "Unluac";
            case TDECOMPILE:
                return "TDECOMPILE";
            case GG_MODIFIER:
                return "GG修改器";
            default:
                return "未知工具";
        }
    }

    /**
     * 获取文件名
     */
    private String getFileName(Uri uri) {
        String path = uri.getPath();
        if (path != null) {
            int cut = path.lastIndexOf('/');
            if (cut != -1) {
                return path.substring(cut + 1);
            }
        }
        return uri.getLastPathSegment();
    }

    /**
     * 显示项目列表弹窗
     */
    private void showProjectListDialog(DecompilerType decompilerType) {
        String message = String.format("%s - 项目列表功能开发中...",
                getDecompilerName(decompilerType));
        Toast.makeText(getContext(), message, Toast.LENGTH_SHORT).show();
    }

    /**
     * 显示批量处理弹窗
     */
    private void showBatchProcessDialog() {
        Toast.makeText(getContext(), "TDECOMPILE批量处理功能开发中...", Toast.LENGTH_SHORT).show();
    }


    /**
     * 处理Unluac反编译
     */
    private void processUnluacDecompile(Uri fileUri) {
        Log.d("TAG", "Processing Unluac decompile for: " + fileUri.toString());
        // TODO: 实现Unluac反编译逻辑
        Toast.makeText(getContext(), "正在使用Unluac进行反编译...", Toast.LENGTH_SHORT).show();
    }

    /**
     * 处理TDECOMPILE反编译
     */
    private void processTdecompileDecompile(Uri fileUri) {
        Log.d("TAG", "Processing TDECOMPILE decompile for: " + fileUri.toString());
        // TODO: 实现TDECOMPILE反编译逻辑
        Toast.makeText(getContext(), "正在使用TDECOMPILE进行高级反编译...", Toast.LENGTH_SHORT).show();

        // 模拟反编译过程
        new android.os.Handler().postDelayed(() -> {
            Toast.makeText(getContext(), "TDECOMPILE: 检测到加密层，正在解密...", Toast.LENGTH_SHORT).show();
        }, 1000);
    }

    /**
     * 处理GG修改器反编译
     */
    private void processGGModifierDecompile(Uri fileUri) {
        Log.d("TAG", "Processing GG Modifier decompile for: " + fileUri.toString());
        // TODO: 实现GG修改器反编译逻辑
        Toast.makeText(getContext(), "正在使用GG修改器进行反编译...", Toast.LENGTH_SHORT).show();
    }
}