package mituran.gglua.tool.licenseModel;


import android.os.Bundle;
import android.view.MenuItem;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import mituran.gglua.tool.R;
import mituran.gglua.tool.licenseModel.LicenseAdapter;
import mituran.gglua.tool.licenseModel.LicenseModel;
import java.util.ArrayList;
import java.util.List;

public class OpenSourceLicenseActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private LicenseAdapter adapter;
    private List<LicenseModel> licenseList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_open_source_license);

        // 设置Toolbar
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("开源许可");
        }

        // 初始化RecyclerView
        recyclerView = findViewById(R.id.recycler_view_licenses);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        // 加载许可证数据
        loadLicenses();

        // 设置适配器
        adapter = new LicenseAdapter(this, licenseList);
        recyclerView.setAdapter(adapter);
    }

    private void loadLicenses() {
        licenseList = new ArrayList<>();

        // 添加你的开源库许可证信息
        // Apache License 2.0 示例
        licenseList.add(new LicenseModel(
                "sora-editor",
                "Rosemoe",
                "https://github.com/Rosemoe/sora-editor",
                "LGPL",
                getLicenseText("sora-editor")
        ));

        // MIT License 示例
        licenseList.add(new LicenseModel(
                "",
                "",
                "",
                "",
                getLicenseText("")
        ));

        // 添加更多库...
        licenseList.add(new LicenseModel(
                "",
                "",
                "",
                "",
                getLicenseText("")
        ));
    }

    private String getLicenseText(String licenseType) {
        switch (licenseType) {
            case "sora-editor":
                return"sora-editor - the awesome code editor for Android"+
            "https://github.com/Rosemoe/sora-editor"+
            "Copyright (C) 2020-2024  Rosemoe"+
            "This library is free software; you can redistribute it and/or"+
            "modify it under the terms of the GNU Lesser General Public"+
            "License as published by the Free Software Foundation; either"+
            "version 2.1 of the License, or (at your option) any later version." + "This library is distributed in the hope that it will be useful," +
            "but WITHOUT ANY WARRANTY; without even the implied warranty of"+
            "MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU"+
            "Lesser General Public License for more details."+
            "You should have received a copy of the GNU Lesser General Public"+
            "License along with this library; if not, write to the Free Software"+
            "Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301 USA"+
            "Please contact Rosemoe by email 2073412493@qq.com if you need"+
            "additional information or have any questions";

            case "glide":
                return "License for everything not in third_party and not otherwise marked:\n\n" +
                        "Copyright 2014 Google, Inc. All rights reserved.\n\n" +
                        "Redistribution and use in source and binary forms, with or without modification...";

            default:
                return "";
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
}