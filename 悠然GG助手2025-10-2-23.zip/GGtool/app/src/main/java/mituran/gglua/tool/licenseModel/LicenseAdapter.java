package mituran.gglua.tool.licenseModel;


import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;
import mituran.gglua.tool.R;
import mituran.gglua.tool.licenseModel.LicenseModel;
import java.util.List;

public class LicenseAdapter extends RecyclerView.Adapter<LicenseAdapter.ViewHolder> {

    private List<LicenseModel> licenseList;
    private Context context;

    public LicenseAdapter(Context context, List<LicenseModel> licenseList) {
        this.context = context;
        this.licenseList = licenseList;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_license, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        LicenseModel license = licenseList.get(position);

        holder.tvLibraryName.setText(license.getLibraryName());
        holder.tvAuthor.setText(license.getAuthor());
        holder.tvLicenseType.setText(license.getLicenseType());
        holder.tvLicenseText.setText(license.getLicenseText());

        // 默认折叠许可证文本
        holder.tvLicenseText.setVisibility(View.GONE);
        holder.isExpanded = false;

        // 点击卡片展开/折叠许可证文本
        holder.cardView.setOnClickListener(v -> {
            if (holder.isExpanded) {
                holder.tvLicenseText.setVisibility(View.GONE);
                holder.isExpanded = false;
            } else {
                holder.tvLicenseText.setVisibility(View.VISIBLE);
                holder.isExpanded = true;
            }
        });

        // 点击库名打开链接
        holder.tvLibraryName.setOnClickListener(v -> {
            if (license.getLibraryUrl() != null && !license.getLibraryUrl().isEmpty()) {
                Intent intent = new Intent(Intent.ACTION_VIEW);
                intent.setData(Uri.parse(license.getLibraryUrl()));
                context.startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return licenseList.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvLibraryName, tvAuthor, tvLicenseType, tvLicenseText;
        CardView cardView;
        boolean isExpanded = false;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.card_license);
            tvLibraryName = itemView.findViewById(R.id.tv_library_name);
            tvAuthor = itemView.findViewById(R.id.tv_author);
            tvLicenseType = itemView.findViewById(R.id.tv_license_type);
            tvLicenseText = itemView.findViewById(R.id.tv_license_text);
        }
    }
}